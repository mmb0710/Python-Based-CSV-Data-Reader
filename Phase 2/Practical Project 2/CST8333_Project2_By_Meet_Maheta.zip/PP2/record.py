# record.py

# Author: Meet Maheta

class TrafficRecord:
    """
    A class to represent a traffic record.
    """

    def __init__(self, section_id, highway, section, section_length, section_description, date, description, group, type_, county, ptrucks, adt, aadt, direction, pct85, priority_points):
        """
        Initialize a TrafficRecord with all necessary fields.

        Parameters
        ----------
        section_id : str
            The section ID of the traffic record.
        highway : str
            The highway name or number.
        section : str
            The section of the highway.
        section_length : str
            The length of the section.
        section_description : str
            A description of the section.
        date : str
            The date of the record.
        description : str
            A detailed description of the record.
        group : str
            The group classification.
        type_ : str
            The type classification.
        county : str
            The county where the section is located.
        ptrucks : str
            The percentage of trucks.
        adt : str
            The Average Daily Traffic.
        aadt : str
            The Annual Average Daily Traffic.
        direction : str
            The direction of traffic.
        pct85 : str
            The 85th percentile speed.
        priority_points : str
            The priority points of the section.
        """
        self.section_id = section_id
        self.highway = highway
        self.section = section
        self.section_length = section_length
        self.section_description = section_description
        self.date = date
        self.description = description
        self.group = group
        self.type_ = type_
        self.county = county
        self.ptrucks = ptrucks
        self.adt = adt
        self.aadt = aadt
        self.direction = direction
        self.pct85 = pct85
        self.priority_points = priority_points

    def __repr__(self):
        """
        Return a string representation of the TrafficRecord.

        Returns
        -------
        str
            A string representation of the TrafficRecord.
        """
        return (f"TrafficRecord({self.section_id}, {self.highway}, {self.section}, {self.section_length}, "
                f"{self.section_description}, {self.date}, {self.description}, {self.group}, {self.type_}, "
                f"{self.county}, {self.ptrucks}, {self.adt}, {self.aadt}, {self.direction}, {self.pct85}, "
                f"{self.priority_points})")
