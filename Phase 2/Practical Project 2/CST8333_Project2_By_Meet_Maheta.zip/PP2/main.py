# Author: Meet Maheta
# main.py

from business import TrafficManager
from presentation import display_records, display_menu, get_user_choice, get_record_details, display_message

def main():
    """
    The main function to run the traffic data management program.
    It initializes the TrafficManager and provides a menu-driven interface for user interaction.
    """
    filename = "Traffic_Volumes_-_Provincial_Highway_System.csv"
    manager = TrafficManager(filename)  # Initialize the TrafficManager with the given filename

    while True:
        display_menu()  # Display the main menu
        choice = get_user_choice()  # Get the user's choice from the menu
        
        if choice is None:
            continue

        if choice == 1:
            display_message("Reloading data...")
            manager.reload_data()  # Reload data from the CSV file
            display_message(f"Successfully loaded {len(manager.records)} records.")
        
        elif choice == 2:
            display_message("Saving data...")
            manager.save_data()  # Save data to the CSV file
            display_message("Data saved successfully.")
        
        elif choice == 3:
            num_records = int(input("Enter the number of records to display: "))
            display_records(manager.records, num_records)  # Display the specified number of records
        
        elif choice == 4:
            display_message("Adding a new record...")
            details = get_record_details()  # Get new record details from the user
            manager.add_record({
                'section_id': details[0],
                'highway': details[1],
                'section': details[2],
                'section_length': details[3],
                'section_description': details[4],
                'date': details[5],
                'description': details[6],
                'group': details[7],
                'type_': details[8],
                'county': details[9],
                'ptrucks': details[10],
                'adt': details[11],
                'aadt': details[12],
                'direction': details[13],
                'pct85': details[14],
                'priority_points': details[15]
            })  # Add the new record to the manager
            display_message("Record added successfully.")
        
        elif choice == 5:
            display_message("Editing a record...")
            section_id = input("Enter the SECTION ID of the record to edit: ")
            details = get_record_details()  # Get updated record details from the user
            index = next((i for i, r in enumerate(manager.records) if r.section_id == section_id), None)
            if index is not None and manager.edit_record(index, {
                'section_id': details[0],
                'highway': details[1],
                'section': details[2],
                'section_length': details[3],
                'section_description': details[4],
                'date': details[5],
                'description': details[6],
                'group': details[7],
                'type_': details[8],
                'county': details[9],
                'ptrucks': details[10],
                'adt': details[11],
                'aadt': details[12],
                'direction': details[13],
                'pct85': details[14],
                'priority_points': details[15]
            }):
                display_message("Record edited successfully.")
            else:
                display_message("Record not found.")
        
        elif choice == 6:
            display_message("Deleting a record...")
            section_id = input("Enter the SECTION ID of the record to delete: ")
            index = next((i for i, r in enumerate(manager.records) if r.section_id == section_id), None)
            if index is not None and manager.delete_record(index):
                display_message("Record deleted successfully.")
            else:
                display_message("Record not found.")
        
        elif choice == 0:
            display_message("Exiting program.")
            break
        
        else:
            display_message("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
