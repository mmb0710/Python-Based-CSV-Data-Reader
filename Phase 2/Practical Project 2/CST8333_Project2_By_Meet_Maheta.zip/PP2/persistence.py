# persistence.py

# Author: Meet Maheta

import pandas as pd
from business import TrafficRecord

def load_data(filename):
    """
    Load data from a CSV file and return a list of TrafficRecord objects.

    Parameters
    ----------
    filename : str
        The name of the CSV file to load data from.

    Returns
    -------
    list of TrafficRecord
        A list of TrafficRecord objects.
    """
    try:
        df = pd.read_csv(filename)
        records = []
        for i, row in df.iterrows():
            if i >= 100:  # Limit to first 100 records
                break
            record = TrafficRecord(
                row['SECTION ID'], row['HIGHWAY'], row['SECTION'], 
                row['SECTION LENGTH'], row['SECTION DESCRIPTION'], 
                row['Date'], row['DESCRIPTION'], row['GROUP'], 
                row['TYPE'], row['COUNTY'], row['PTRUCKS'], 
                row['ADT'], row['AADT'], row['DIRECTION'], 
                row['85PCT'], row['PRIORITY_POINTS']
            )
            records.append(record)
        print(f"Successfully loaded {len(records)} records.")
        return records
    except FileNotFoundError:
        print("File not found.")
        return []

def save_data(records, filename):
    """
    Save a list of TrafficRecord objects to a CSV file.

    Parameters
    ----------
    records : list of TrafficRecord
        The list of TrafficRecord objects to save.
    filename : str
        The name of the CSV file to save data to.
    """
    data = [{
        'SECTION ID': record.section_id,
        'HIGHWAY': record.highway,
        'SECTION': record.section,
        'SECTION LENGTH': record.section_length,
        'SECTION DESCRIPTION': record.section_description,
        'Date': record.date,
        'DESCRIPTION': record.description,
        'GROUP': record.group,
        'TYPE': record.type_,
        'COUNTY': record.county,
        'PTRUCKS': record.ptrucks,
        'ADT': record.adt,
        'AADT': record.aadt,
        'DIRECTION': record.direction,
        '85PCT': record.pct85,
        'PRIORITY_POINTS': record.priority_points
    } for record in records]

    df = pd.DataFrame(data)
    df.to_csv(filename, index=False)
    print("Data saved successfully.")
