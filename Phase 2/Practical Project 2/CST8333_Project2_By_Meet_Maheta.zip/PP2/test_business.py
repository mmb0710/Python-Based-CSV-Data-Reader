# test_business.py

# Author: Meet Maheta

import unittest
from business import TrafficManager

class TestTrafficManager(unittest.TestCase):
    """
    Unit tests for the TrafficManager class.
    """

    def setUp(self):
        """
        Set up the test environment by initializing a TrafficManager instance.
        """
        self.manager = TrafficManager('Traffic_Volumes_-_Provincial_Highway_System.csv')

    def test_add_record(self):
        """
        Test the add_record method to ensure it correctly adds a new record.
        """
        initial_count = len(self.manager.records)
        self.manager.add_record({
            'section_id': '9999', 'highway': 'H', 'section': 'S', 'section_length': '1',
            'section_description': 'Desc', 'date': '2023-01-01', 'description': 'Desc',
            'group': 'G', 'type_': 'T', 'county': 'C', 'ptrucks': 'P', 'adt': 'A',
            'aadt': 'A', 'direction': 'D', 'pct85': '85', 'priority_points': 'PP'
        })
        self.assertEqual(len(self.manager.records), initial_count + 1)

    def test_reload_data(self):
        """
        Test the reload_data method to ensure it correctly reloads the data.
        """
        self.manager.reload_data()
        self.assertGreater(len(self.manager.records), 0)

    def test_edit_record(self):
        """
        Test the edit_record method to ensure it correctly edits an existing record.
        """
        self.manager.add_record({
            'section_id': '9999', 'highway': 'H', 'section': 'S', 'section_length': '1',
            'section_description': 'Desc', 'date': '2023-01-01', 'description': 'Desc',
            'group': 'G', 'type_': 'T', 'county': 'C', 'ptrucks': 'P', 'adt': 'A',
            'aadt': 'A', 'direction': 'D', 'pct85': '85', 'priority_points': 'PP'
        })
        index = len(self.manager.records) - 1
        self.manager.edit_record(index, {'adt': '2000'})
        self.assertEqual(self.manager.get_record(index).adt, '2000')

    def test_delete_record(self):
        """
        Test the delete_record method to ensure it correctly deletes a record.
        """
        self.manager.add_record({
            'section_id': '9999', 'highway': 'H', 'section': 'S', 'section_length': '1',
            'section_description': 'Desc', 'date': '2023-01-01', 'description': 'Desc',
            'group': 'G', 'type_': 'T', 'county': 'C', 'ptrucks': 'P', 'adt': 'A',
            'aadt': 'A', 'direction': 'D', 'pct85': '85', 'priority_points': 'PP'
        })
        index = len(self.manager.records) - 1
        self.manager.delete_record(index)
        self.assertIsNone(self.manager.get_record(index))

if __name__ == "__main__":
    unittest.main()
